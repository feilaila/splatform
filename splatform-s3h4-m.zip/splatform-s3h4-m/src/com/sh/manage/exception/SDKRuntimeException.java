package com.sh.manage.exception;
/**
 * 
 * Title. XX类<br>
 * Description.
 * <p>
 * Copyright: Copyright (c) 2014年11月30日
 * <p>
 * Company: ff
 * <p>
 * Author: fuzl
 * <p>
 * Version: 1.0
 * <p>
 */
public class SDKRuntimeException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public SDKRuntimeException(String str) {
	        super(str);
	 }
}
